import React, { FC } from 'react'

const Discover: FC = () => {
	return (
		<div>
			<h2>Discover</h2>
		</div>
	)
}

export default Discover
