import React, { FC } from 'react'

const Footer: FC = () => {
	return (
		<footer>
			<h2>Footer</h2>
		</footer>
	)
}

export default Footer
